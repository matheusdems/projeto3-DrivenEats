let num1 = 0;
let num2 = 0;
let num3 = 0;

function selecionaPedido(pedidoBotao){

    const botaoSelecionado = document.querySelector(".esconder");

    

  if (botaoSelecionado !== null) {
    botaoSelecionado.classList.add("esconder");
  }

    const seletor = "." + pedidoBotao;
    const botao = document.querySelector(seletor);
    botao.classList.toggle("esconder");

    num1 = 1;
    
    

    }

    function selecionaRefri(pedidoBotao){

        const botaoSelecionado = document.querySelector(".esconder");
    
       
      if (botaoSelecionado !== null) {
        botaoSelecionado.classList.add("esconder");
      }
    
        const seletor = "." + pedidoBotao;
        const botao = document.querySelector(seletor);
        botao.classList.toggle("esconder");
        num2 = 1;
            
     }

     function selecionaSobremesa(pedidoBotao){

        const botaoSelecionado = document.querySelector(".esconder");
    
            
      if (botaoSelecionado !== null) {
        botaoSelecionado.classList.add("esconder");
      }
    
        const seletor = "." + pedidoBotao;
        const botao = document.querySelector(seletor);
        botao.classList.toggle("esconder");
    
        num3 = 1;
        let soma = num1 + num2 + num3;
        console.log(soma)
        if (soma === 3){
            const botaoFechar = document.querySelector(".botao-selecionado");
            botaoFechar.classList.add("pedido-fechado")
        
            botaoFechar.innerHTML = 'Fechar pedido'

        }
        
    
        }
    